/* DUKH Attack 
 * COMP10002 Foundations of Algorithms, Semester 1, 2021
 * Skeleton code written by Shaanan Cohney, April 2021
 
 * //algorithms are awesome!!!!!
 * Full Name: Ryan Goh Rui En      
 * Student Number: 1191761 
 * Date:   25/4/2021         
 */

/****** Include libraries ******/

#include <stdio.h>
#include <stdlib.h>
/* Do NOT use the following two libraries in stage 1! */
#include <string.h>
#include <ctype.h>

/* Provides functions AES_encrypt and AES_decrypt (see the assignment spec) */
#include "aes.h"
/* Provides functions to submit your work for each stage.
 * See the definitions in a1grader.h, they are all available to use.
 * But don't submit your stages more than once... that's weird! */
#include "a1grader.h"

/****** Definitions of constants ******/

#define BOOK_LENGTH 1284         /* The maximum length of a cipher book */
#define MAX_MSG_LENGTH 1024      /* The maximum length of an encrypted message */
#define BLOCKSIZE 16             /* The length of a block (key, output) */
#define N_TIMESTEPS 20           /* number of timesteps */
#define N_OUTPUT_BLOCKS 2        /* number of output blocks */

// TODO Add your own #defines here, if needed



/****** Type definitions ******/
/* Recall that these are merely aliases, or shortcuts to their underlying types.
 * For example, block_t can be used in place of an array, length 16 (BLOCKSIZE)
 * of unsigned char, and vice versa. */

typedef char book_t[BOOK_LENGTH];     /* A cipherbook (1284 bytes) */
typedef unsigned char byte_t;         /* A byte (8 bits) */
typedef byte_t block_t[BLOCKSIZE];    /* A cipher bitset (block) (16 bytes) */
typedef byte_t msg_t[MAX_MSG_LENGTH]; /* An encrypted message (l bytes) */

// TODO Add your own type definitions here, if needed



/****** Function Prototypes ******
 * There are more functions defined in aes.h and grader.h */
// Scaffold

int read_hex_line(byte_t output[], int max_count, char *last_char);

// Hint: Variables passed by pointers should be modified in your stages' implementation!

void stage0(msg_t ciphertext, int *ciphertext_length, 
            block_t outputs[N_OUTPUT_BLOCKS], block_t timesteps[N_TIMESTEPS], 
            book_t cipherbook);
void stage1(book_t cipherbook, int *book_len);
void stage2(byte_t codebook[], int book_len, block_t outputs[N_OUTPUT_BLOCKS], 
            block_t timesteps[N_TIMESTEPS], block_t key2);
void stage3(block_t key2, block_t outputs[N_OUTPUT_BLOCKS], 
            block_t timesteps[N_TIMESTEPS], byte_t key1[], int cipher_length);
void stage4(byte_t key1[], byte_t ciphertext[], int cipher_length, 
            byte_t plaintext[]);

// TODO: Put your own function prototypes here! Recommended: separate into stages.

//Stage 1 function prototypes
int alphanumeric_check(char checkchar);

//Stage 2 function prototypes
void xor_function(block_t xorA, block_t xorB, block_t xoroutput, int size);
void copy_block(byte_t* block1, byte_t* block2, int size);
int check_lhs_rhs(block_t lhs, block_t rhs);

/* The main function of the program */
// It is strongly suggested you do NOT modify this function.
int main(int argc, char *argv[])
{   
    //// Stage 0
    /* These will store our input from the input file */
    msg_t ciphertext;                  // encrypted message, to be decrypted in the attack
    int ciphertext_length = 0;         // length of the encrypted message
    book_t cipherbook;                 // book used to make key k2
    block_t timesteps[N_TIMESTEPS];    // timesteps used to generate outputs (hex)
    block_t outputs[N_OUTPUT_BLOCKS];  // outputs from the random number generator (hex)

    // Run your stage 0 code
    stage0(ciphertext, &ciphertext_length, outputs, timesteps, cipherbook);
    // And submit the results.  Don't delete this...
    submit_stage0(ciphertext_length, ciphertext, outputs, timesteps, cipherbook);
    
    //// Stage 1
    int book_len = 0;    // length of the cipher book after having removed punctuation
    stage1(cipherbook, &book_len);
    submit_stage1(cipherbook, book_len);

    //// Stage 2
    block_t key2;        // the key k2 (hexadecimal)
    stage2((byte_t *) cipherbook, book_len, outputs, timesteps, key2);
    submit_stage2(key2);

    //// Stage 3
    byte_t key1[MAX_MSG_LENGTH];       // the key k2 (hexadecimal)
    stage3(key2, outputs, timesteps, key1, ciphertext_length);    
    submit_stage3(key1);

    //// Stage 4
    byte_t plaintext[MAX_MSG_LENGTH];  // the plaintext output
    stage4(key1, ciphertext, ciphertext_length, plaintext);
    submit_stage4(plaintext);

    return 0;
}

/********* Scaffold Functions *********/

/* Reads a line in from stdin, converting pairs of hexadecimal (0-F) chars to
 * byte_t (0-255), storing the result into the output array, 
 * stopping after max_count values are read, or a newline is read.
 *
 * Returns the number of *bytes* read.
 * The last char read in from stdin is stored in the value pointed to by last_char.
 * If you don't need to know what last_char is, set that argument to NULL
 */
int read_hex_line(byte_t output[], int max_count, char *last_char)
{
    char hex[2];
    int count;
    for (count = 0; count < max_count; count++)
    {
        /* Consider the first character of the hex */
        hex[0] = getchar();
        if (hex[0] == '\n')
        {
            if (last_char)
            {
                *last_char = hex[0];
            }
            break;
        }
        /* Now the second */
        hex[1] = getchar();
        if (last_char)
        {
            *last_char = hex[0];
        }
        if (hex[1] == '\n')
        {
            break;
        }

        /* Convert this hex into an int and store it */
        output[count] = hex_to_int(hex); // (defined in aes.h)
    }

    return count - 1;
}

/********* Stage 0 Functions *********/

void stage0(msg_t ciphertext, int *ciphertext_length, block_t outputs[N_OUTPUT_BLOCKS], 
            block_t timesteps[N_TIMESTEPS], book_t cipherbook) 
{
    // TODO: Implement stage 0!
    // Read line 1
    scanf("%d \n  ", ciphertext_length);
    
    //Read line 2
    read_hex_line(ciphertext, *ciphertext_length, NULL);
    scanf("\n");
    
    //Read line 3 
    read_hex_line(outputs[0], BLOCKSIZE, NULL);
    read_hex_line(outputs[1], BLOCKSIZE, NULL);
    scanf("\n");
    
    //Read line 4
    for(int timestep_counter=1; timestep_counter<=N_TIMESTEPS; timestep_counter++){
        read_hex_line(timesteps[timestep_counter-1], BLOCKSIZE, NULL);
    }
    scanf("\n");
    
    //Read line 5
    for(int cipherbook_counter=1; cipherbook_counter<=BOOK_LENGTH; cipherbook_counter++){
        cipherbook[cipherbook_counter-1]=getchar();
    }
    /* !! Submission Instructions !! Store your results in the variables:
     *      ciphertext, ciphertext_length, outputs, timesteps, cipherbook
     * These are passed to submit_stage0 for some useful output and submission. */
}

// TODO: Add functions here, if needed.

/********* Stage 1 Functions *********/
// Reminder: you *cannot* use string.h or ctype.h for this stage!

void stage1(book_t cipherbook, int *book_len) 
{
    // TODO: Implement stage 1!
    //Declaration
    int alphanumericcounter = 0;
    
    //Loop through the cipherbook to remove on alphaneumeric alphabets and update the length of the new array
    for(int cipherbook_counter=1; cipherbook_counter<=BOOK_LENGTH; cipherbook_counter++){
        
        
        if(alphanumeric_check(cipherbook[cipherbook_counter-1])){
            cipherbook[alphanumericcounter]=cipherbook[cipherbook_counter-1];
            alphanumericcounter++;
        }
    }
    
    *book_len=alphanumericcounter;
    
    /* !! Submission Instructions !! Store your results in the variables:
     *      cipherbook, book_len
     * These are passed to submit_stage1 for some useful output and submission. */
}

// TODO: Add functions here, if needed.

//This function checks if the character is alphanumeric. It returns 1 if it is and 0 if otherwise.
int alphanumeric_check(char checkchar){
    if ((checkchar >= 'a' && checkchar <= 'z') || (checkchar >= 'A' && checkchar <= 'Z')){
            return 1;
        }
    return 0;
}

/********* Stage 2 Functions *********/


void stage2(byte_t codebook[], int book_len, block_t outputs[N_OUTPUT_BLOCKS], 
            block_t timesteps[N_TIMESTEPS], block_t key2) 
{
    // TODO: Implement stage 2!
    //Declaration
    block_t decrypt_O10,encrypt_T10,encrypt_T09, lhs;
    block_t xor_O09_encrypt_T09, xor_decrypt_O10_encrypt_T10;
    
 
    //create two dimensional array for key
    byte_t key[book_len/BLOCKSIZE][BLOCKSIZE];
    for(int rows=0;rows<(book_len/BLOCKSIZE);rows++){
        for(int column=0;column<BLOCKSIZE;column++){
            key[rows][column]=codebook[(rows*BLOCKSIZE)+column];
        }
    }
    
    //looping values of possible keys into the equation 1
    for (int key_counter=0;key_counter<=(book_len/BLOCKSIZE);key_counter++){
        //find RHS
        //AESk(T09)
        AES_encrypt(timesteps[9],key[key_counter],encrypt_T09);
        //O09 xor AESk(T09)
        xor_function(encrypt_T09, outputs[0], xor_O09_encrypt_T09, BLOCKSIZE);
        
        //find LHS
        //AESk(T10)
        AES_encrypt(timesteps[10],key[key_counter],encrypt_T10);
        //AES^-1kO10
        AES_decrypt(outputs[1],key[key_counter],decrypt_O10);
        //AES^-1kO10 xor AESk(T10)
        xor_function(encrypt_T10, decrypt_O10, xor_decrypt_O10_encrypt_T10, BLOCKSIZE);
        // AES^-1k(AES^-1kO10 xor AESk(T10))
        AES_decrypt(xor_decrypt_O10_encrypt_T10,key[key_counter],lhs);
        
       
        
        
        if(check_lhs_rhs(lhs,xor_O09_encrypt_T09)==BLOCKSIZE){
            //insert values into key2
            copy_block(&key[key_counter][0], &key2[0], BLOCKSIZE);
            //break because key is already found
            break;
        }
        
        
        
    } 
   
    
    
    /* !! Submission Instructions !! Store your results in the variable:
     *      key2
     * These will be passed to submit_stage2 to let you see some useful output! */
}

// TODO: Add functions here, if needed.
//This function will XOR the first two arguments and put the result in the third argument. The forth argument takes in the size of the arrays 
void xor_function(block_t xorA, block_t xorB, block_t xoroutput, int size){
    for(int xorcounter=0; xorcounter<size;xorcounter++){
            xoroutput[xorcounter]=xorA[xorcounter]^xorB[xorcounter];
        }
}

//This function copies the contents of block1 into block2
void copy_block(byte_t* block1, byte_t* block2, int size){
    for(int copycounter=0;copycounter<size;copycounter++){
                block2[copycounter]=block1[copycounter];
            }
           
}
//This function compares lhs and rhs of the equation. If all 16 values of the block_t matches, it returns BLOCKSIZE.
int check_lhs_rhs(block_t lhs, block_t rhs){
    int checking =0 ;
    while (checking<BLOCKSIZE){
        if (lhs[checking]==rhs[checking]){
                checking++;
            }
            else{
                //break because line is no longer the key
                break;
            }
    }
   
    return checking;
}

/********* Stage 3 Functions *********/

void stage3(block_t key2, block_t outputs[N_OUTPUT_BLOCKS], 
            block_t timesteps[N_TIMESTEPS], byte_t key1[], int ciphertext_length) 
{
    // TODO: Implement stage 3!
    //Declarations
    block_t currentstate,encrypt_T10,xor_O10_encrypt_T10;
    block_t intermediatevalue, xor_intermediatevalue_currentstate,encrypt_xor_intermediatevalue_currentstate,xor_010_intermediatevalue;
    int ivalue=11;
    int key1counter=0;
    
    //getting the secret state
    AES_encrypt(timesteps[10],key2,encrypt_T10);
    xor_function(encrypt_T10, outputs[1], xor_O10_encrypt_T10, BLOCKSIZE);
    AES_encrypt(xor_O10_encrypt_T10,key2,currentstate);
    
    //finding other O values 
    for(int Ovalue=0;Ovalue<ciphertext_length/BLOCKSIZE;Ovalue++){
        AES_encrypt(timesteps[ivalue],key2,intermediatevalue);
        xor_function(intermediatevalue, currentstate, xor_intermediatevalue_currentstate, BLOCKSIZE);
        AES_encrypt(xor_intermediatevalue_currentstate,key2,encrypt_xor_intermediatevalue_currentstate);
        
        for(int input_key1=0; input_key1<BLOCKSIZE; input_key1++){
            key1[key1counter]=encrypt_xor_intermediatevalue_currentstate[input_key1];
            key1counter++; //prints to 127
            
        }
        //update currentstate
        xor_function(intermediatevalue, encrypt_xor_intermediatevalue_currentstate, xor_010_intermediatevalue, BLOCKSIZE);
        AES_encrypt(xor_010_intermediatevalue,key2,currentstate);
        ivalue++;
    }
    
    
    /* !! Submission Instructions !! Store your results in the variable:
     *      key1
     * These will be passed to submit_stage3 to let you see some useful output! */
}

// TODO: Add functions here, if needed.

/********* Stage 4 Functions *********/
void stage4(byte_t key1[], byte_t ciphertext[], int cipher_length, byte_t plaintext[])
{
    // TODO: Implement stage 4!
    xor_function(key1, ciphertext, plaintext, cipher_length);
    //algorithms are awesome!!!!!

    /* !! Submission Instructions !! Store your results in the variable:
     *      plaintext
     * These will be passed to submit_stage4 to let you see some useful output! */
}

// TODO: Add functions here, if needed.


/********* END OF ASSIGNMENT! *********/
/* If you would like to try the bonus stage, attempt it in a new file, bonus.c */
// Feel free to write a comment to the marker or the lecturer below...